# React + CSS export

Copy the code and assets folders into your React app. FigmaExport.jsx imports FigmaExport.css. Image fills use relative paths under assets. React must be installed in the target project.
