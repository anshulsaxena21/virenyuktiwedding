import React from "react";
import "./FigmaExport.css";

export default function FigmaExport() {
  return (
    <main className="figma-1119-3">
      <div className="figma-1119-4">
        <div className="figma-1119-5"></div>
        <div className="figma-1119-6">
          <div className="figma-1119-7"></div>
          <div className="figma-1119-8"></div>
        </div>
        <div className="figma-1119-9">
          <div className="figma-1119-10">
            <div className="figma-1119-11">
              <div className="figma-1119-12"></div>
              <div className="figma-1119-13"></div>
            </div>
            <div className="figma-1119-14">
              <div className="figma-1119-15"></div>
              <div className="figma-1119-16">
                <div className="figma-1119-17"></div>
                <div className="figma-1119-18"></div>
                <div className="figma-1119-19"></div>
                <p className="figma-1119-20">
❦
                </p>
                <p className="figma-1119-21">
Together with our families
                </p>
                <div className="figma-1119-22">
                  <p className="figma-1119-23">
◆
                  </p>
                </div>
                <div className="figma-1119-24">
                  <p className="figma-1119-25">
Viren
                  </p>
                  <p className="figma-1119-26">
&amp;
                  </p>
                  <p className="figma-1119-27">
Yukti
                  </p>
                </div>
                <div className="figma-1119-28">
                  <p className="figma-1119-29">
◆
                  </p>
                </div>
                <p className="figma-1119-30">
Do dil ek jaan, ab shuru hoga naya safar.
                </p>
                <div className="figma-1119-31"></div>
                <p className="figma-1119-32">
⌖
                </p>
                <p className="figma-1119-33">
7:00 PM onwards
Suhaag Wedding Point, Bareilly
                </p>
                <div className="figma-1119-34">
                  <p className="figma-1119-35">
◆
                  </p>
                </div>
                <div className="figma-1119-36">
                  <p className="figma-1119-37">
Scroll now
                  </p>
                  <p className="figma-1119-38">
⌄
                  </p>
                </div>
                <div className="figma-1119-39">
                  <p className="figma-1119-40">
11
                  </p>
                  <p className="figma-1119-41">
Days
                  </p>
                  <p className="figma-1119-42">
07
                  </p>
                  <p className="figma-1119-43">
Hours
                  </p>
                  <p className="figma-1119-44">
◆
                  </p>
                  <p className="figma-1119-45">
23
                  </p>
                  <p className="figma-1119-46">
Minutes
                  </p>
                  <p className="figma-1119-47">
◆
                  </p>
                  <p className="figma-1119-48">
07
                  </p>
                  <p className="figma-1119-49">
Seconds
                  </p>
                  <p className="figma-1119-50">
◆
                  </p>
                </div>
                <div className="figma-1119-51">
                  <div className="figma-1119-52"></div>
                  <p className="figma-1119-53">
Save the Date
                  </p>
                  <div className="figma-1119-54">
                    <p className="figma-1119-55">
›
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="figma-1119-56">
            <div className="figma-1119-57"></div>
            <p className="figma-1119-58">
॥ मङ्गलम् ॥
            </p>
            <p className="figma-1119-59">
ॐ कृष्णाय वासुदेवाय हरये परमात्मने।
प्रणतः क्लेशनाशाय गोविन्दाय नमो नमः॥
            </p>
            <p className="figma-1119-60">
With the divine grace of the Almighty and the
blessings of our elders, we cordially invite you and
your family to grace the auspicious wedding
ceremony of our children.
            </p>
            <p className="figma-1119-61">
Groom's Family
            </p>
            <p className="figma-1119-62">
Son of Sri Hari Pal Singh &amp; Smt. Shobha Singh
            </p>
            <p className="figma-1119-63">
Bride's Family
            </p>
            <p className="figma-1119-64">
Daughter of Sri Vijai Singh &amp; Smt. Manju Singh
            </p>
          </div>
          <div className="figma-1119-65">
            <div className="figma-1119-66">
              <p className="figma-1119-67">
With love &amp; blessings
              </p>
              <p className="figma-1119-68">
Our Families
              </p>
              <div className="figma-1119-69">
                <p className="figma-1119-70">
◆
                </p>
              </div>
            </div>
            <div className="figma-1119-71">
              <div className="figma-1119-72">
                <div className="figma-1119-73">
                  <div className="figma-1119-74"></div>
                </div>
                <div className="figma-1119-75">
                  <div className="figma-1119-76"></div>
                  <p className="figma-1119-77">
Sri Hari Pal Singh
                  </p>
                  <p className="figma-1119-78">
Father of the Groom
                  </p>
                </div>
              </div>
              <div className="figma-1119-79">
                <div className="figma-1119-80"></div>
                <p className="figma-1119-81">
Smt. Shobha Singh
                </p>
                <p className="figma-1119-82">
Mother of the Groom
                </p>
              </div>
            </div>
            <div className="figma-1119-83"></div>
            <div className="figma-1119-84">
              <div className="figma-1119-85">
                <div className="figma-1119-86">
                  <div className="figma-1119-87"></div>
                </div>
                <div className="figma-1119-88">
                  <div className="figma-1119-89"></div>
                  <p className="figma-1119-90">
Sri Vijai Singh
                  </p>
                  <p className="figma-1119-91">
Father of the Bride
                  </p>
                </div>
              </div>
              <div className="figma-1119-92">
                <div className="figma-1119-93"></div>
                <p className="figma-1119-94">
Smt. Manju Singh
                </p>
                <p className="figma-1119-95">
Mother of the Bride
                </p>
              </div>
            </div>
            <div className="figma-1119-96"></div>
          </div>
          <div className="figma-1119-97">
            <div className="figma-1119-98">
              <p className="figma-1119-99">
How it began
              </p>
              <p className="figma-1119-100">
Our Love Story
              </p>
              <div className="figma-1119-101">
                <p className="figma-1119-102">
◆
                </p>
              </div>
            </div>
            <div className="figma-1119-103">
              <div className="figma-1119-104"></div>
              <div className="figma-1119-105">
                <div className="figma-1119-106">
                  <p className="figma-1119-107">
♥
                  </p>
                </div>
                <div className="figma-1119-108">
                  <div className="figma-1119-109"></div>
                  <div className="figma-1119-110">
                    <p className="figma-1119-111">
Chapter 01 · 2 November 2017
                    </p>
                    <div className="figma-1119-112">
                      <p className="figma-1119-113">
◆
                      </p>
                    </div>
                  </div>
                  <p className="figma-1119-114">
How We Met
                  </p>
                  <p className="figma-1119-115">
It all began in college — two strangers, a few shared classes and endless
conversations. What started as friendship slowly became the most
beautiful part of our everyday.
                  </p>
                  <div className="figma-1119-116">
                    <div className="figma-1119-117"></div>
                  </div>
                </div>
              </div>
              <div className="figma-1119-118">
                <div className="figma-1119-119">
                  <p className="figma-1119-120">
♥
                  </p>
                </div>
                <div className="figma-1119-121">
                  <div className="figma-1119-122"></div>
                  <div className="figma-1119-123">
                    <p className="figma-1119-124">
Chapter 02 · 22 February 2026
                    </p>
                    <div className="figma-1119-125">
                      <p className="figma-1119-126">
◆
                      </p>
                    </div>
                  </div>
                  <p className="figma-1119-127">
Families Said Yes
                  </p>
                  <p className="figma-1119-128">
Our families met over sweets and smiles, and two homes became one.
With their blessings, our journey together truly began.
                  </p>
                  <div className="figma-1119-129">
                    <div className="figma-1119-130"></div>
                  </div>
                </div>
              </div>
              <div className="figma-1119-131">
                <div className="figma-1119-132">
                  <p className="figma-1119-133">
♥
                  </p>
                </div>
                <div className="figma-1119-134">
                  <div className="figma-1119-135"></div>
                  <div className="figma-1119-136">
                    <p className="figma-1119-137">
Chapter 03 · 10 April 2026
                    </p>
                    <div className="figma-1119-138">
                      <p className="figma-1119-139">
◆
                      </p>
                    </div>
                  </div>
                  <p className="figma-1119-140">
The Sagai
                  </p>
                  <p className="figma-1119-141">
Surrounded by our loved ones, we exchanged rings and a promise of
forever — the day our story turned into a lifetime.
                  </p>
                  <div className="figma-1119-142">
                    <div className="figma-1119-143"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="figma-1119-144">
            <div className="figma-1119-145">
              <p className="figma-1119-146">
Reveal
              </p>
            </div>
            <div className="figma-1119-147">
              <p className="figma-1119-148">
Save the Date
              </p>
              <p className="figma-1119-149">
Scratch the card below to reveal it
              </p>
            </div>
            <div className="figma-1119-150">
              <p className="figma-1119-151">
We're Getting Married!
              </p>
              <p className="figma-1119-152">
6 December 2026
              </p>
              <p className="figma-1119-153">
7:00 PM onwards
              </p>
              <p className="figma-1119-154">
Save the date and join us in celebration
              </p>
            </div>
            <div className="figma-1119-155"></div>
            <div className="figma-1119-156">
              <p className="figma-1119-157">
👆 Scratch to reveal our
date
              </p>
            </div>
          </div>
          <div className="figma-1119-158">
            <div className="figma-1119-159">
              <p className="figma-1119-160">
The Celebrations
              </p>
              <p className="figma-1119-161">
Our Wedding Journey
              </p>
              <div className="figma-1119-162">
                <p className="figma-1119-163">
◆
                </p>
              </div>
            </div>
            <div className="figma-1119-164"></div>
            <div className="figma-1119-165">
              <p className="figma-1119-166">
01 · Ceremony
              </p>
              <div className="figma-1119-167">
                <p className="figma-1119-168">
Mehendi
                </p>
                <div className="figma-1119-169"></div>
              </div>
              <div className="figma-1119-170">
                <p className="figma-1119-171">
Date
                </p>
                <p className="figma-1119-172">
Saturday, 5 December 2026
                </p>
                <p className="figma-1119-173">
Time
                </p>
                <p className="figma-1119-174">
7:00 PM
                </p>
                <p className="figma-1119-175">
Venue
                </p>
                <p className="figma-1119-176">
1, Mithilapuri Phase 2, near Prakash Dental Clinic,
Bareilly
                </p>
              </div>
              <div className="figma-1119-177">
                <p className="figma-1119-178">
Directions →
                </p>
              </div>
              <div className="figma-1119-179">
                <div className="figma-1119-180"></div>
                <p className="figma-1119-181">
🌿
                </p>
                <p className="figma-1119-182">
मेहंदी
                </p>
              </div>
              <div className="figma-1119-183"></div>
            </div>
            <div className="figma-1119-184">
              <p className="figma-1119-185">
02 · Ceremony
              </p>
              <div className="figma-1119-186">
                <p className="figma-1119-187">
Sangeet
                </p>
                <div className="figma-1119-188"></div>
              </div>
              <div className="figma-1119-189">
                <p className="figma-1119-190">
Date
                </p>
                <p className="figma-1119-191">
Saturday, 5 December 2026
                </p>
                <p className="figma-1119-192">
Time
                </p>
                <p className="figma-1119-193">
7:00 PM
                </p>
                <p className="figma-1119-194">
Venue
                </p>
                <p className="figma-1119-195">
1, Mithilapuri Phase 2, near Prakash Dental Clinic,
Bareilly
                </p>
              </div>
              <div className="figma-1119-196">
                <p className="figma-1119-197">
Directions →
                </p>
              </div>
              <div className="figma-1119-198">
                <div className="figma-1119-199"></div>
                <p className="figma-1119-200">
🎶
                </p>
                <p className="figma-1119-201">
संगीत
                </p>
              </div>
              <div className="figma-1119-202"></div>
            </div>
            <div className="figma-1119-203">
              <p className="figma-1119-204">
03 · Ceremony
              </p>
              <div className="figma-1119-205">
                <p className="figma-1119-206">
Shubh Vivah
                </p>
                <div className="figma-1119-207"></div>
              </div>
              <p className="figma-1119-208">
Baraat · Varmala · Pheras
              </p>
              <div className="figma-1119-209">
                <p className="figma-1119-210">
Date
                </p>
                <p className="figma-1119-211">
Sunday, 6 December 2026
                </p>
                <p className="figma-1119-212">
Time
                </p>
                <p className="figma-1119-213">
7:00 PM
                </p>
                <p className="figma-1119-214">
Venue
                </p>
                <p className="figma-1119-215">
Suhaag Wedding Point, Bareilly
                </p>
                <p className="figma-1119-216">
Dress code
                </p>
                <p className="figma-1119-217">
Traditional
                </p>
              </div>
              <div className="figma-1119-218">
                <p className="figma-1119-219">
Directions →
                </p>
              </div>
              <div className="figma-1119-220">
                <div className="figma-1119-221"></div>
                <p className="figma-1119-222">
🪔
                </p>
                <p className="figma-1119-223">
विवाह
                </p>
              </div>
              <div className="figma-1119-224"></div>
            </div>
          </div>
          <div className="figma-1119-225">
            <div className="figma-1119-226">
              <p className="figma-1119-227">
Moments
              </p>
              <p className="figma-1119-228">
Rituals &amp; Portraits
              </p>
              <div className="figma-1119-229">
                <p className="figma-1119-230">
◆
                </p>
              </div>
            </div>
            <div className="figma-1119-231">
              <div className="figma-1119-232">
                <div className="figma-1119-233"></div>
              </div>
              <div className="figma-1119-234"></div>
              <p className="figma-1119-235">
In each other's arms
              </p>
            </div>
            <div className="figma-1119-237">
              <div className="figma-1119-238">
                <div className="figma-1119-239"></div>
              </div>
              <div className="figma-1119-240"></div>
              <p className="figma-1119-241">
The bride
              </p>
            </div>
            <div className="figma-1119-243">
              <div className="figma-1119-244">
                <div className="figma-1119-245"></div>
              </div>
              <div className="figma-1119-246"></div>
              <p className="figma-1119-247">
The groom
              </p>
            </div>
            <div className="figma-1119-249">
              <div className="figma-1119-250">
                <div className="figma-1119-251"></div>
              </div>
              <div className="figma-1119-252"></div>
              <p className="figma-1119-253">
A moment of pure joy
              </p>
            </div>
            <div className="figma-1119-255">
              <div className="figma-1119-256">
                <div className="figma-1119-257"></div>
              </div>
              <div className="figma-1119-258"></div>
              <p className="figma-1119-259">
Rings, petals &amp; blessings
              </p>
            </div>
            <div className="figma-1119-261">
              <div className="figma-1119-262">
                <div className="figma-1119-263"></div>
              </div>
              <div className="figma-1119-264"></div>
              <p className="figma-1119-265">
Together, forever
              </p>
            </div>
          </div>
          <div className="figma-1119-267">
            <div className="figma-1119-268">
              <p className="figma-1119-269">
Find Us
              </p>
              <p className="figma-1119-270">
Venue
              </p>
              <div className="figma-1119-271">
                <p className="figma-1119-272">
◆
                </p>
              </div>
            </div>
            <div className="figma-1119-273">
              <p className="figma-1119-274">
Mehendi &amp; Sangeet
              </p>
              <p className="figma-1119-275">
Our Home
              </p>
              <p className="figma-1119-276">
1, Mithilapuri Phase 2, near Prakash Dental Clinic, Bareilly
              </p>
              <p className="figma-1119-277">
Saturday, 5 December 2026 · 7:00 PM
              </p>
              <div className="figma-1119-278">
                <p className="figma-1119-279">
Get Directions
                </p>
              </div>
              <div className="figma-1119-280">
                <div className="figma-1119-281">
                  <p className="figma-1119-282">
📍
                  </p>
                </div>
              </div>
            </div>
            <div className="figma-1119-283">
              <p className="figma-1119-284">
Shubh Vivah
              </p>
              <p className="figma-1119-285">
Suhaag Wedding Point
              </p>
              <p className="figma-1119-286">
Bareilly, Uttar Pradesh
              </p>
              <p className="figma-1119-287">
Sunday, 6 December 2026 · 7:00 PM onwards
              </p>
              <div className="figma-1119-288">
                <p className="figma-1119-289">
Get Directions
                </p>
              </div>
              <div className="figma-1119-290">
                <div className="figma-1119-291">
                  <p className="figma-1119-292">
📍
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="figma-1119-293">
            <p className="figma-1119-294">
॥ शुभ विवाह ॥
            </p>
            <p className="figma-1119-295">
Viren &amp; Yukti
            </p>
            <div className="figma-1119-296">
              <p className="figma-1119-297">
#YUVIkiShaadi
              </p>
              <p className="figma-1119-298">
 ⧉
              </p>
            </div>
            <div className="figma-1119-299">
              <p className="figma-1119-300">
Contacts for the day
              </p>
              <p className="figma-1119-301">
For directions or any help on the day
              </p>
              <div className="figma-1119-302">
                <div className="figma-1119-303">
                  <p className="figma-1119-304">
Groom's Father
Sri Hari Pal Singh
                  </p>
                  <p className="figma-1119-305">
+91 74177 86700
                  </p>
                  <div className="figma-1119-306">
                    <p className="figma-1119-307">
📞
                    </p>
                  </div>
                  <div className="figma-1119-308">
                    <p className="figma-1119-309">
💬
                    </p>
                  </div>
                </div>
                <div className="figma-1119-310">
                  <p className="figma-1119-311">
Groom
Viren
                  </p>
                  <p className="figma-1119-312">
+91 92583 83836
                  </p>
                  <div className="figma-1119-313">
                    <p className="figma-1119-314">
📞
                    </p>
                  </div>
                  <div className="figma-1119-315">
                    <p className="figma-1119-316">
💬
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <p className="figma-1119-317">
Crafted with love · Viren &amp; Yukti
            </p>
          </div>
        </div>
        <div className="figma-1119-318"></div>
        <div className="figma-1119-319">
          <p className="figma-1119-320">
♫
          </p>
        </div>
      </div>
    </main>
  );
}
